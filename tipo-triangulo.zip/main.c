/******************************************************************************

Leandro Crapino
22/03/2023
Faça um programa que receba os três lados de um triângulo e faça as seguintes atividades: retornar se os três lados
realmente formam um triângulo e que tipo de triângulo é este. Cada uma destas atividades deve ser uma função.

*******************************************************************************/
#include <stdio.h>

int leia() {
  int lado;
  scanf("%d", &lado);
  return lado;
}

int formaTriangulo(int a, int b, int c) {
  if (a < b + c && b < a + c && c < a + b) {
    return 1; 
  } else {
    return 0; 
  }
}

void mostraTipo(int a, int b, int c) {
  if (a == b && b == c) {
    printf("O triângulo é equilátero\n");
  } else if (a == b || a == c || b == c) {
    printf("O triângulo é isósceles\n");
  } else {
    printf("O triângulo é escaleno\n");
  }
}

int main() {
  int a, b, c;

  printf("Digite o primeiro lado: ");
  a = leia();

  printf("Digite o segundo lado: ");
  b = leia();

  printf("Digite o terceiro lado: ");
  c = leia();

  if (formaTriangulo(a, b, c)) {
    mostraTipo(a, b, c);
  } else {
    printf("Os lados não formam um triângulo\n");
  }

  return 0;
}