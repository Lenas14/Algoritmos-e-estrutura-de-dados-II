/******************************************************************************

Leandro da Silva Crapino
01/03/2023
Leia um vetor de 10 posições.
Conte e escreva quantos valores pares ele possui 

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i, vetor[10], contador = 0;
    
    for(i = 0; i < 10; i++){
        printf("Digite o valor da posicao %d: ", i);
        scanf("%d", &vetor[i]);
        if (vetor[i] % 2 == 0)
        contador++;
    }
    
    printf("A quantidade de numeros pares e de: %d\n", contador);
return 0;
}

