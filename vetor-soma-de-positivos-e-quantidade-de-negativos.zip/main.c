/******************************************************************************

Leandro da Silva Crapino
01/03/2023
Faça um programa que preencha um vetor com 10 números reais.
Calcule e mostre:
a)A soma dos números positivos desse vetor e a quantidade de negativos

*******************************************************************************/
#include <stdio.h>

int main()
{
    float vetor[10], positivos = 0, negativos = 0;
    int i;
    
    for(i = 0; i < 10; i++){
        printf("Digite o valor da posicao %d: ", i);
        scanf("%f", &vetor[i]);
        if(vetor[i] < 0) negativos++;
        else positivos = positivos + vetor[i];
    }    
    printf("A soma dos positivos e: %.2f\n", positivos);
    printf("A quantidade de negativos e: %.2f\n", negativos);
    return 0;
}

